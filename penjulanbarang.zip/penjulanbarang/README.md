# penjualanbarang
Penjualan barang di toko x
